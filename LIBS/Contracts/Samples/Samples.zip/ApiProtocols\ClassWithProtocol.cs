﻿using System;
using System.IO;
using System.Diagnostics.Contracts;

public class ClassWithProtocol
{

  public ClassWithProtocol()
  {
  }

  string _data;

  public void Initialize(string data)
  {
    this._data = data;
  }

  public string Data
  {
    get
    {
      return _data;
    }
  }


  string _computedData;
  public string ComputedData
  {
    get
    {
      return _computedData;
    }

  }

  public void Compute(string prefix)
  {
    this._computedData = prefix + _data;
  }
  
}
