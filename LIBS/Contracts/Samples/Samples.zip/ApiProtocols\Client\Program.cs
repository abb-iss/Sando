﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client
{
  class Program
  {
    static void Main(string[] args)
    {
      var sum = NullableProtocol.Sum(null, 5);

      var c = new ClassWithProtocol();

      var arg = "TestString";
      if (args.Length > 0 && args[0] != null)
      {
        arg = args[0];
      }
      c.Initialize(arg);

      var data = c.ComputedData;

      Console.WriteLine(data.ToString());

    }


  }
}
