﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics.Contracts;

namespace CodeContracts.Samples
{
  public class Search
  {

    public static int BinarySearch(int[] array, int value)
    {
      int inf = 0;
      int sup = array.Length - 1;

      while (inf <= sup)
      {
        int index = (inf + sup) >> 1;

        int mid = array[index];

        if (value == mid)
          return index;
        if (mid < value)
          inf = index + 1;
        else
          sup = index - 1;
      }
      return -1;
    }
  }
}
