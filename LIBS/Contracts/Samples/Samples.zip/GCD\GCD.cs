﻿using System;
using System.Diagnostics.Contracts;

namespace CodeContracts.Samples
{
  public class MyMath
  {
    public static int GCD(int x, int y)
    {
      while (true)
      {
        if (x < y)
        {
          y %= x;
          if (y == 0)
          {
            return x;
          }
        }
        else
        {
          x %= y;
          if (x == 0)
          {
            return y;
          }
        }
      }
    }
  }

  public class Rational
  {
    int d, n;
    bool pos;

    static public Rational NormalizedRational(bool pos, int x, int y)
    {
      if (x == 0)
      {
        return new Rational(true, 0, 1);
      }

      int gcd = MyMath.GCD(x, y);
      return new Rational(pos, x / gcd, y / gcd);
    }

    private Rational(bool pos, int x, int y)
    {
      this.pos = pos;
      this.d = x;
      this.n = y;
    }
  }

}
