﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;


namespace Demo
{
  public class ZuneDate
  {
 
    public static int YearSince1980(int daysSince1980, out int dayInYear)
    {
      Contract.Requires(daysSince1980 >= 1);

      Contract.Ensures(Contract.ValueAtReturn(out dayInYear) >= 1);
      Contract.Ensures(Contract.ValueAtReturn(out dayInYear) <= 366);
      Contract.Ensures(DateTime.IsLeapYear(Contract.Result<int>()) || Contract.ValueAtReturn(out dayInYear) <= 365);

      var year = 1980;
      var daysLeft = daysSince1980;

      while (daysLeft > 365)
      {
        var oldDaysLeft = daysLeft;
        if (DateTime.IsLeapYear(year))
        {
          if (daysLeft > 366)
          {
            daysLeft -= 366;
            year += 1;
          }
          else
          {
            dayInYear = daysLeft;
            return year;
          }
        }
        else
        {
          daysLeft -= 365;
          year += 1;
        }
        Contract.Assert(daysLeft < oldDaysLeft);
      }

      dayInYear = daysLeft;
      return year;
    }

  }
}
