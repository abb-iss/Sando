﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeContracts.Samples
{
  class Sample1
  {
    static void Main(string[] args)
    {
      var r1 = new Rational(10, 5);

      Console.WriteLine("r1 truncated = {0}", r1.Truncate());

      var r2 = new PositiveDenominatorRational(5, 3);

      r2.Divide(-5);

      var r3 = new PositiveDenominatorRational(5, 0);

      var r4 = new NormalizedRational(10, 2);

      r4.Divide(0);

      Console.WriteLine("r1 truncated = {0}", r3.Truncate());
    }
  }
}
