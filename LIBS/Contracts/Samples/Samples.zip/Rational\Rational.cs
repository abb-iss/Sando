﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace CodeContracts.Samples {

  public class Rational {
    public int Numerator { get; protected set; }
    public int Denominator { get; protected set; }

    public Rational(int n, int d) {
      Contract.Requires(d != 0);

      this.Numerator = n;
      this.Denominator = d;
    }

    [ContractInvariantMethod]
    private void RationalInvariant() {
      Contract.Invariant(Denominator != 0);
    }

    public virtual void Add(Rational other) {
      Contract.Requires(other != null);
      int newN = this.Numerator * other.Denominator + other.Numerator * this.Denominator;
      int newD = this.Denominator * other.Denominator;

      this.Numerator = newN;
      this.Denominator = newD;
    }

    public static Rational operator +(Rational a, Rational b) {
      Contract.Requires(a != null);
      Contract.Requires(b != null);
      return new Rational(a.Numerator * b.Denominator + b.Numerator * a.Denominator, a.Denominator * b.Denominator);
    }
    public static Rational operator +(Rational a, int b) {
      Contract.Requires(a != null);
      return new Rational(a.Numerator + b * a.Denominator, a.Denominator);
    }

    public virtual void Divide(int divisor)
    {
      Contract.Requires<ArgumentOutOfRangeException>(divisor != 0);

      this.Denominator = this.Denominator * divisor;
    }

    public int Truncate()
    {
      return this.Numerator / this.Denominator;
    }

    public virtual void Invert() {
      Contract.Ensures(Contract.OldValue(this.Numerator) == this.Denominator && Contract.OldValue(this.Denominator) == this.Numerator);

      int num = this.Numerator;
      int den = this.Denominator;
      this.Numerator = den;
      this.Denominator = num;
    }

  }

}
